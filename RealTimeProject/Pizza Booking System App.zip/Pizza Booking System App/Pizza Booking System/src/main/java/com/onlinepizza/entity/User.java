package com.onlinepizza.entity;

public class User {
	private Integer userId;
	private String userName;
	private String password;
	private Long contactNo;
	private String email;
	private String city;
	//Admin, Customer
	private String userRole;

}
