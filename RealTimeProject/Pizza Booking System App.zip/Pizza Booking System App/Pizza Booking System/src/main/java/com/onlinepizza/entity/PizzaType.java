package com.onlinepizza.entity;

import java.util.List;

public class PizzaType {
	private Integer pizzaTypeId;
	// Veg or Non-Veg
	private String pizzaType;
	private List<Toppings> toppings;

}
