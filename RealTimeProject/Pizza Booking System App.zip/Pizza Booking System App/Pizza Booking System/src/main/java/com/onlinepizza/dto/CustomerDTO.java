package com.onlinepizza.dto;

public class CustomerDTO extends UserDTO {
	private String customerName;
	private Long customerMobile;
	private String customerEmail;
	private String customerAddress;
	
}
