package com.onlinepizza.exception;

public class GlobalExceptionHandler {
	
}
