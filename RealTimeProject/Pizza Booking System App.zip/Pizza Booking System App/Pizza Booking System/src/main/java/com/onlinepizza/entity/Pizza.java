package com.onlinepizza.entity;

import com.onlinepizza.util.PizzaSize;

public class Pizza {
	private Integer pizzaId;
	private PizzaType pizzaType;
	private String pizzaName;
	private String pizzaDescription;
	// Base Price
	private Double pizzaCost;
	private PizzaSize pizzaSize;
	
}
